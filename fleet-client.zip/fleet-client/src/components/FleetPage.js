import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import {
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  Paper, Typography, Container, TableSortLabel
} from '@mui/material';
import Map, { Marker, Popup } from 'react-map-gl';
import { TextField, Box, Button } from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';


export default function FleetPage() {
  const { id } = useParams();
  const [vessels, setVessels] = useState([]);
  const [selectedVessel, setSelectedVessel] = useState(null);
  const [order, setOrder] = useState('asc');
  const [orderBy, setOrderBy] = useState('name');
  const [searchParams, setSearchParams] = useState({ name: '', mmsi: '', flag: '' });

const handleInputChange = (e) => {
  setSearchParams({ ...searchParams, [e.target.name]: e.target.value });
};

const handleSearch = async () => {
  const query = new URLSearchParams(
    Object.fromEntries(Object.entries(searchParams).filter(([_, v]) => v))
  ).toString();

  const res = await fetch(`http://localhost:3000/vessels/search?${query}`);
  const data = await res.json();
  setVessels(data);
};


  useEffect(() => {
    fetch(`http://localhost:3000/fleets/${id}/vessels`)
      .then(res => res.json())
      .then(setVessels);
  }, [id]);

  const handleSort = (property) => {
    const isAsc = orderBy === property && order === 'asc';
    setOrder(isAsc ? 'desc' : 'asc');
    setOrderBy(property);
  };

  const sortedVessels = [...vessels].sort((a, b) => {
    if (orderBy === 'name') {
      return order === 'asc'
        ? a.name.localeCompare(b.name)
        : b.name.localeCompare(a.name);
    } else {
      return order === 'asc'
        ? (a.value || 0) - (b.value || 0)
        : (b.value || 0) - (a.value || 0);
    }
  });

  return (
    <Container>
      <Typography variant="h4" sx={{ my: 3 }}>Fleet Vessels</Typography>
        <Box
  sx={{
    display: 'flex',
    gap: 2,
    mb: 3,
    flexWrap: 'wrap',
    alignItems: 'center'
  }}
>
  <TextField
    label="Name"
    name="name"
    value={searchParams.name}
    onChange={handleInputChange}
    variant="outlined"
    size="small"
  />
  <TextField
    label="MMSI"
    name="mmsi"
    value={searchParams.mmsi}
    onChange={handleInputChange}
    variant="outlined"
    size="small"
  />
  <TextField
    label="Flag"
    name="flag"
    value={searchParams.flag}
    onChange={handleInputChange}
    variant="outlined"
    size="small"
  />
  <Button
    variant="contained"
    startIcon={<SearchIcon />}
    onClick={handleSearch}
  >
    Search
  </Button>
</Box>

      {/* Table */}
      <TableContainer component={Paper} sx={{ mb: 4 }}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>
                <TableSortLabel
                  active={orderBy === 'name'}
                  direction={orderBy === 'name' ? order : 'asc'}
                  onClick={() => handleSort('name')}
                >
                  Vessel Name
                </TableSortLabel>
              </TableCell>
              <TableCell align="right">
                <TableSortLabel
                  active={orderBy === 'value'}
                  direction={orderBy === 'value' ? order : 'asc'}
                  onClick={() => handleSort('value')}
                >
                  Value
                </TableSortLabel>
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {sortedVessels.map(v => (
              <TableRow key={v._id}>
                <TableCell>{v.name || v._id}</TableCell>
                <TableCell align="right">{v.value || '-'}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      {/* Map Section */}
      <Map
        initialViewState={{
          longitude: 80,
          latitude: 6,
          zoom: 5
        }}
        style={{ width: '100%', height: 500 }}
        mapStyle="mapbox://styles/mapbox/streets-v11"
        mapboxAccessToken="YOUR_MAPBOX_TOKEN"
      >
        {vessels.map(v => v.location && (
          <Marker
            key={v._id}
            longitude={v.location.longitude}
            latitude={v.location.latitude}
            onClick={() => setSelectedVessel(v)}
          />
        ))}

        {selectedVessel && (
          <Popup
            longitude={selectedVessel.location.longitude}
            latitude={selectedVessel.location.latitude}
            onClose={() => setSelectedVessel(null)}
          >
            <div>
              <strong>{selectedVessel.name || selectedVessel._id}</strong>
              <p>Value: {selectedVessel.value}</p>
              <p>Lat: {selectedVessel.location.latitude}</p>
              <p>Lon: {selectedVessel.location.longitude}</p>
            </div>
          </Popup>
        )}
      </Map>
    </Container>
  );
}
