import React, { useEffect, useState } from 'react';
import {
  Container,
  Grid,
  Card,
  CardContent,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  CircularProgress,
  Collapse,
  Button
} from '@mui/material';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import ExpandLessIcon from '@mui/icons-material/ExpandLess';

const API_BASE = 'http://localhost:3000';

function App() {
  const [fleets, setFleets] = useState([]);
  const [expandedFleet, setExpandedFleet] = useState(null);
  const [vessels, setVessels] = useState({});
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetch(`${API_BASE}/fleets`)
      .then(res => res.json())
      .then(data => setFleets(data))
      .catch(console.error);
  }, []);

  const handleExpand = async (fleetId) => {
    if (expandedFleet === fleetId) {
      setExpandedFleet(null);
      return;
    }

    setLoading(true);
    const response = await fetch(`${API_BASE}/fleets/${fleetId}/vessels`);
    const data = await response.json();
    setVessels(prev => ({ ...prev, [fleetId]: data }));
    setExpandedFleet(fleetId);
    setLoading(false);
  };

  return (
    <Container sx={{ py: 5, backgroundColor: '#f9f9fb', minHeight: '100vh' }}>
      <Typography
        variant="h3"
        align="center"
        gutterBottom
        sx={{ fontWeight: 'bold', color: '#333', mb: 4 }}
      >
        🌊 Fleet Overview Dashboard
      </Typography>

      <Grid container spacing={3}>
        {fleets.map(fleet => (
          <Grid item xs={12} md={6} lg={4} key={fleet._id}>
            <Card elevation={4} sx={{ borderRadius: 3 }}>
              <CardContent>
                <Typography variant="h6" sx={{ color: '#1976d2', fontWeight: 600 }}>
                  {fleet.name}
                </Typography>
                <Typography variant="body2" sx={{ color: '#555' }}>
                  Vessels: {fleet.vesselCount}
                </Typography>

                <Button
                  variant="text"
                  endIcon={expandedFleet === fleet._id ? <ExpandLessIcon /> : <ExpandMoreIcon />}
                  onClick={() => handleExpand(fleet._id)}
                  sx={{ mt: 1 }}
                >
                  {expandedFleet === fleet._id ? 'Hide Vessels' : 'Show Vessels'}
                </Button>

                <Collapse in={expandedFleet === fleet._id}>
                  {loading ? (
                    <CircularProgress size={24} sx={{ display: 'block', mt: 2, mx: 'auto' }} />
                  ) : (
                    <TableContainer component={Paper} sx={{ mt: 2 }}>
                      <Table size="small">
                        <TableHead>
                          <TableRow>
                            <TableCell><strong>Vessel Name</strong></TableCell>
                            <TableCell><strong>Flag</strong></TableCell>
                            <TableCell><strong>Size</strong></TableCell>
                            <TableCell><strong>Draught</strong></TableCell>
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          {(vessels[fleet._id] || []).map(v => (
                            <TableRow key={v._id}>
                              <TableCell>{v.name || 'N/A'}</TableCell>
                              <TableCell>{v.flag || '—'}</TableCell>
                              <TableCell>{v.size || '—'}</TableCell>
                              <TableCell>{v.draught || '—'}</TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </TableContainer>
                  )}
                </Collapse>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>
    </Container>
  );
}

export default App;
