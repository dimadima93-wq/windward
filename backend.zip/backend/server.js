const express = require('express');
const fs = require('fs');
const path = require('path');
const cors = require('cors');



const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(cors());
// Helper to read JSON files
function readJSON(filename) {
  const filePath = path.join(__dirname, 'data', filename);
  const rawData = fs.readFileSync(filePath, 'utf8');
  return JSON.parse(rawData);
}

// Load data
const fleets = readJSON('fleets (5).json');
const vessels = readJSON('vessels (3).json');
const vesselLocations = readJSON('vesselLocations (3).json');

// Combine vessel info with location info
const vesselsWithLocation = vessels.map(vessel => {
  const location = vesselLocations.find(loc => loc.vesselId === vessel._id);
  return { ...vessel, location };
});

// Combine fleets with their vessels
const enrichedFleets = fleets.map(fleet => {
  // extract vessel IDs from the fleet’s vessels list
  const vesselIds = (fleet.vessels || []).map(v => v._id);

  // find the vessel details that match these IDs
  const fleetVessels = vesselsWithLocation.filter(v =>
    vesselIds.includes(v._id)
  );

  return { ...fleet, vessels: fleetVessels };
});

// Route: return each fleet’s name and vessel count
app.get('/fleets', (req, res) => {
  const summary = enrichedFleets.map(fleet => ({
    _id: fleet._id,
    name: fleet.name,
    vesselCount: fleet.vessels.length
  }));
  res.json(summary);
});


app.get('/fleets/:id/vessels', (req, res) => {
  const fleetId = req.params.id;
  const fleet = enrichedFleets.find(f => f._id === fleetId);

  if (!fleet) {
    return res.status(404).json({ message: 'Fleet not found' });
  }

  res.json(fleet.vessels);
});

// Search vessels by name, flag, MMSI
app.get('/vessels/search', (req, res) => {
  const { name, flag, mmsi } = req.query;

  const filters = [];
  if (name) filters.push(v => v.name?.toLowerCase().includes(name.toLowerCase()));
  if (flag) filters.push(v => v.flag?.toLowerCase().includes(flag.toLowerCase()));
  if (mmsi) filters.push(v => String(v.mmsi).includes(String(mmsi)));

  let results = vesselsWithLocation;
  if (filters.length) results = results.filter(v => filters.every(fn => fn(v)));

  res.json(results);
});



// Optional: route to get full details of one fleet
app.get('/fleet/:id', (req, res) => {
  const fleet = enrichedFleets.find(f => f._id === req.params.id);
  if (!fleet) {
    return res.status(404).json({ message: 'Fleet not found' });
  }
  res.json(fleet);
});

// Start server
app.listen(PORT, () => {
  console.log(`✅ Server running on port ${PORT}`);
});
