export async function fetchFleets() {
  const res = await fetch('http://localhost:3000/fleets');
  return res.json();
}
