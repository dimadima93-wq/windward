import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { fetchFleets } from '../api';
import {
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  Paper, TableSortLabel, Typography, Container
} from '@mui/material';

export default function FleetList() {
  const [fleets, setFleets] = useState([]);
  const [order, setOrder] = useState('asc');
  const [orderBy, setOrderBy] = useState('name');
  const navigate = useNavigate();

  useEffect(() => {
    fetchFleets().then(setFleets);
  }, []);

  const handleSort = (property) => {
    const isAsc = orderBy === property && order === 'asc';
    setOrder(isAsc ? 'desc' : 'asc');
    setOrderBy(property);
  };

  const sortedFleets = [...fleets].sort((a, b) => {
    if (orderBy === 'vesselCount') {
      return order === 'asc' ? a.vesselCount - b.vesselCount : b.vesselCount - a.vesselCount;
    } else {
      return order === 'asc'
        ? a.name.localeCompare(b.name)
        : b.name.localeCompare(a.name);
    }
  });

  return (
    <Container>
      <Typography variant="h4" align="center" sx={{ my: 3 }}>Fleets</Typography>
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>
                <TableSortLabel
                  active={orderBy === 'name'}
                  direction={orderBy === 'name' ? order : 'asc'}
                  onClick={() => handleSort('name')}
                >
                  Fleet Name
                </TableSortLabel>
              </TableCell>
              <TableCell align="right">
                <TableSortLabel
                  active={orderBy === 'vesselCount'}
                  direction={orderBy === 'vesselCount' ? order : 'asc'}
                  onClick={() => handleSort('vesselCount')}
                >
                  Vessel Count
                </TableSortLabel>
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {sortedFleets.map((fleet) => (
              <TableRow
                key={fleet.name}
                hover
                sx={{ cursor: 'pointer' }}
                onClick={() => navigate(`/fleet/${fleet._id}`)}
              >
                <TableCell>{fleet.name}</TableCell>
                <TableCell align="right">{fleet.vesselCount}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </Container>
  );
}
